export const VehicleClass:any[] = [
  "Transport",
  "LMV",
  "HGV"
];
export const TypeOfDriver:any[] = [
  "Permanent",
  "Learner",
];
export const Gender:any[] = [
  "Female",
  "Male"
];
