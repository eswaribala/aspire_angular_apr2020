export const Purpose:any[]=[
  "Business",
  "Personal",
  "Others"
]
