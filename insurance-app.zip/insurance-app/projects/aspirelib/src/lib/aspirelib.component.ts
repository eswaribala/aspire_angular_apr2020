import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-aspirelib',
  template: `
    <p>
      aspirelib works!
    </p>
  `,
  styles: []
})
export class AspirelibComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
