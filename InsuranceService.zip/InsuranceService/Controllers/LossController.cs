﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InsuranceService.Entities;
using InsuranceService.Repositories;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace InsuranceService.Controllers
{
    [EnableCors("MyPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class LossController : ControllerBase
    {
        private ILossRepository lossRepository;

        public LossController(ILossRepository obj)
        {
            lossRepository = obj;
        }

        // GET api/values
        public IEnumerable<Loss> Get()
        {
            return lossRepository.GetAllLosses();
        }
        // GET api/values
        [EnableCors("MyPolicy")]
        [HttpGet("{id}")]
       
        public Loss Get([FromRoute] int id)
        {
            return lossRepository.GetLoss(id);
        }

        // GET: api/Libraries/GetAllAuthor  
        [EnableCors("MyPolicy")]
        [HttpGet]
        [Route("GetAllLoss")]
    
        public IActionResult GetAllLoss()
        {
            IEnumerable<Loss> authors = lossRepository.GetAllLosses();
            return Ok(authors);
        }
        // POST api/<controller>  
        [EnableCors("MyPolicy")]
        [HttpPost]
        [Route("AddLoss")]
      
        public IActionResult Post([FromBody]Loss loss)
        {
            if (loss == null)
            {
                return BadRequest("Customer is Null");
            }
            lossRepository.SaveLoss(loss);

            return Ok(loss);
        }

    }

}