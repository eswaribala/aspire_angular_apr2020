﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace InsuranceService.Entities
{
    [Table("Loss")]
    public class Loss
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long LossId { set; get; }
        [Required]
        
        public string LostDate { set; get; }
        [Required]
        public string LostTime { set; get; }
        [Required]
        public int Speed {set;get;}
        [Required]
        [MaxLength(150)]
        public string Place { set; get; }
        [Required]
        public string To { set; get; }
        [Required]
        [MaxLength(150)]
        public string Purpose { set; get; }
        [Required]
        public int HeadCount { set; get; }
        [Required]
        [MaxLength(150)]
        public string PoliceStationName { set; get; }
        [Required]
        public long FirNo { set; get; }
        [Required]
        [MaxLength(250)]
        public string Statement { set; get; }
       


    }
}
