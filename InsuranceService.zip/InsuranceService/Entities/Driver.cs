﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace InsuranceService.Entities
{
    [Table("Driver")]
    public class Driver
    {
        [Key]
        public string ContactNumber { set; get; }
        [Required]
        [MaxLength(50)]
        public string DriverName { set; get; }
        [Required]
        [MaxLength(50)]
        public string RelationShip { set; get; }
        [Required]
        [MaxLength(150)]
        public string Address { set; get; }
        [Required]
        public DateTime DateOfBirth { set; get; }
        [Required]
        public string Gender { set; get; }
        [Required]
        [MaxLength(150)]
        public string Email { set; get; }
        [Required]
        public string DrivingLicenseNumber { set; get; }
        [Required]
        public DateTime EffectiveFrom { set; get; }
        [Required]
        public DateTime EffectiveTo { set; get; }
        [Required]
        public string IssuingRTO { set; get; }
        [Required]
        public string VehicleClass { set; get; }
        [Required]
        public string TypeOfDriver { set; get; }

        [ForeignKey("LossId")]
        public Loss Loss { get; set; }

        public long LossId { get; set; }

    }
}
