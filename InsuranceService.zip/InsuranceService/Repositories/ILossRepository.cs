﻿using InsuranceService.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InsuranceService.Repositories
{
    public interface ILossRepository
    {
        void SaveLoss(Loss loss);
        IEnumerable<Loss> GetAllLosses();
        Loss GetLoss(long id);
        void DeleteLoss(long id);
        void UpdateLoss(Loss loss);
    }
}
