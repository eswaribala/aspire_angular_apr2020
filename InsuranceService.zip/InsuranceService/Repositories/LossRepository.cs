﻿using InsuranceService.Contexts;
using InsuranceService.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InsuranceService.Repositories
{
    public class LossRepository : IDisposable, ILossRepository
    {

        InsuranceContext _context;
         DbSet<Loss> lossEntity;
        public LossRepository(InsuranceContext context)
        {
            _context = context;
            lossEntity = _context.Set<Loss>();

        }
        public void DeleteLoss(long id)
        {
           Loss loss = GetLoss(id);
            lossEntity.Remove(loss);
            _context.SaveChanges();
        }

        protected void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_context != null)
                {
                    _context.Dispose();
                    _context = null;
                }
            }
        }

        public void Dispose()
        {

            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public IEnumerable<Loss> GetAllLosses()
        {
            return _context.Losses;
        }

        public Loss GetLoss(long id)
        {
            var query = from Loss loss in _context.Losses.ToList()
                        where loss.LossId == id
                        select loss;
            return query.ToList<Loss>().First();
        }

        public void SaveLoss(Loss loss)
        {
            _context.Entry(loss).State = EntityState.Added;
            _context.SaveChanges();
        }

        public void UpdateLoss(Loss loss)
        {
            _context.SaveChanges();
        }
    }
}
