﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace InsuranceService.Migrations
{
    public partial class InsuranceMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Loss",
                columns: table => new
                {
                    LossId = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LostDate = table.Column<string>(nullable: false),
                    LostTime = table.Column<string>(nullable: false),
                    Speed = table.Column<int>(nullable: false),
                    Place = table.Column<string>(maxLength: 150, nullable: false),
                    To = table.Column<string>(nullable: false),
                    Purpose = table.Column<string>(maxLength: 150, nullable: false),
                    HeadCount = table.Column<int>(nullable: false),
                    PoliceStationName = table.Column<string>(maxLength: 150, nullable: false),
                    FirNo = table.Column<long>(nullable: false),
                    Statement = table.Column<string>(maxLength: 250, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Loss", x => x.LossId);
                });

            migrationBuilder.CreateTable(
                name: "Driver",
                columns: table => new
                {
                    ContactNumber = table.Column<string>(nullable: false),
                    DriverName = table.Column<string>(maxLength: 50, nullable: false),
                    RelationShip = table.Column<string>(maxLength: 50, nullable: false),
                    Address = table.Column<string>(maxLength: 150, nullable: false),
                    DateOfBirth = table.Column<DateTime>(nullable: false),
                    Gender = table.Column<string>(nullable: false),
                    Email = table.Column<string>(maxLength: 150, nullable: false),
                    DrivingLicenseNumber = table.Column<string>(nullable: false),
                    EffectiveFrom = table.Column<DateTime>(nullable: false),
                    EffectiveTo = table.Column<DateTime>(nullable: false),
                    IssuingRTO = table.Column<string>(nullable: false),
                    VehicleClass = table.Column<string>(nullable: false),
                    TypeOfDriver = table.Column<string>(nullable: false),
                    LossId = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Driver", x => x.ContactNumber);
                    table.ForeignKey(
                        name: "FK_Driver_Loss_LossId",
                        column: x => x.LossId,
                        principalTable: "Loss",
                        principalColumn: "LossId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Driver_LossId",
                table: "Driver",
                column: "LossId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Driver");

            migrationBuilder.DropTable(
                name: "Loss");
        }
    }
}
