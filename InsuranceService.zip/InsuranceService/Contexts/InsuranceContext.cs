﻿using InsuranceService.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

using System.Linq;
using System.Threading.Tasks;

namespace InsuranceService.Contexts
{
    public class InsuranceContext : DbContext
    {
        public InsuranceContext(DbContextOptions<InsuranceContext> options) : base(options)
        {
          
        }
        public DbSet<Loss> Losses { get; set; }
        public DbSet<Driver> Drivers { get; set; }
    }
}
